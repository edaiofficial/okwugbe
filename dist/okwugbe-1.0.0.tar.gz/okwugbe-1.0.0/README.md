# asr-africa
Automatic Speech Recognition for African Language

## Usage

## Citation
Please cite our paper using the citation below if you use our work in anyway:

@article{2103.07762,
Author = {Bonaventure F. P. Dossou and Chris C. Emezue},
Title = {OkwuGbé: End-to-End Speech Recognition for Fon and Igbo},
Year = {2021},
Eprint = {arXiv:2103.07762},
Howpublished = {African NLP, EACL 2021}
}
