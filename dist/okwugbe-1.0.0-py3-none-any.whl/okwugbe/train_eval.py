import argparse
from model import SpeechRecognitionModel
import torch
import torch.nn.functional as F

parser = argparse.ArgumentParser()

# =========== Model's Arguments ======================================================
# ----------------- LSTM & GRU Parameters --------------------------------------------
parser.add_argument("--rnn_dim", help="RNN Dimension & Hidden Size", default=512, type=int)
parser.add_argument("--num_layers", help="Number of Layers", default=1, type=int)

# ============================== ASR Model Parameters ================================
parser.add_argument("--n_cnn", help="Number of CNN components", default=5, type=int)
parser.add_argument("--n_rnn", help="Number of RNN components", default=3, type=int)
parser.add_argument("--n_class", help="Number of characters + 1", required=True, type=int)
parser.add_argument("--n_feats", help="Number of features for the ResCNN", default=128, type=int)
parser.add_argument("--in_channels", help="Number of input channels of the ResCNN", default=1, type=int)
parser.add_argument("--out_channels", help="Number of output channels of the ResCNN", default=32, type=int)

parser.add_argument("--kernel", help="Kernel Size for the ResCNN", default=3, type=int)
parser.add_argument("--stride", help="Stride Size for the ResCNN", default=2, type=int)
parser.add_argument("--padding", help="Padding Size for the ResCNN", default=1, type=int)
parser.add_argument("--dropout", help="Dropout for all components", default=0.1, type=float)
parser.add_argument("--with_attention",
                    help="True to include attention mechanism, False else", default=False, type=bool)


class IterMeter(object):
    """keeps track of total iterations"""

    def __init__(self):
        self.val = 0

    def step(self):
        self.val += 1

    def get(self):
        return self.val


def main(args):
    n_cnn, n_rnn, rnn_dim, n_class = args.n_cnn, args.n_rnn, args.rnn_dim, args.n_class
    n_feats = args.n_feats
    in_channels, out_channels, kernel = args.in_channels, args.out_channels, args.kernel
    stride, padding = args.stride, args.padding
    dropout, with_attention, num_layers = args.dropout, args.with_attention, args.num_layers

    asr_model = SpeechRecognitionModel(n_cnn, n_rnn, rnn_dim, n_class, n_feats, in_channels, out_channels, kernel,
                                       stride, padding, dropout, with_attention, num_layers)

    print(asr_model)


if __name__ == '__main__':
    args_ = parser.parse_args()
    main(args_)
